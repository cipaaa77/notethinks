<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notethinks</title>
    <link rel="icon" href="/Foto NoteThinks/Logo_Png.png">
    <link rel="stylesheet" href="/login/masuk.css">
</head>

<body>
    <script src="/jsall.js"></script>
    <div class="container">
        <div class="logo-form">
            <div class="logo">
                <img src="/Foto NoteThinks/Logo NoteThinks.jpg" alt="Notethinks Logo">
            </div>
            <div class="form-content">
                <h2>Masuk ke NOTETHINKS!</h2>
                <form action="/login/login-action.php" method="post">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" placeholder="Email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Kata Sandi</label>
                        <input type="password" id="password" placeholder="Kata Sandi" name="password" required>
                    </div>
                    <button type="submit">Login</button>
                </form>
                <div class="login-link">
                    Tidak Punya Akun? <a href="/register">Daftar</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>