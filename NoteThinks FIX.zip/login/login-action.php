<?php
require '../config/database.php';

session_start();
$email = $_POST['email'];
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        $_SESSION['user'] = ['id' => $user['id'], 'name' => $user['fullname'], 'email' => $user['email'], 'image' => $user['image']];
        header('Location: /');
    } else {
        $_SESSION['error'] = 'Kredensial tidak valid';
        header('Location: /login');
    }
} else {
    $_SESSION['error'] = 'Kredensial tidak valid';
    header('Location: /login');
}

$stmt->close();
$conn->close();
