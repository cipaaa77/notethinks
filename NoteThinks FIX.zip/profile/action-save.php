<?php
require_once '../config/database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $id = $_SESSION['user']['id'];

    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpName = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileType = $_FILES['image']['type'];
        $fileSize = $_FILES['image']['size'];

        $uploadDir = '../uploads/';
        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
        $newFileName = uniqid() . '.' . $fileExt;
        $fileDestination = $uploadDir . $newFileName;

        if (move_uploaded_file($fileTmpName, $fileDestination)) {
            $query = "UPDATE users SET fullname = ?, email = ?, phone = ?, image = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssss", $fullname, $email, $phone, $newFileName, $id);

            if ($stmt->execute()) {
                header('Location: /profile');
            } else {
                echo "Error: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Gagal mengupload file.";
        }
    } else {
        $query = "UPDATE users SET fullname = ?, email = ?, phone = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssss", $fullname, $email, $phone, $id);

        if ($stmt->execute()) {
            header('Location: /profile');
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}
