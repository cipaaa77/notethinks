<?php
require_once '../config/database.php';
session_start();
$query = "SELECT fullname, email, phone, image
        FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
if ($stmt === false) {
    die('Error preparing the query: ' . $conn->error);
}
$stmt->bind_param("i", $_SESSION['user']['id']);
$stmt->execute();
$result = $stmt->get_result();

$user = $result->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notethinks</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <link rel="icon" href="/Foto NoteThinks/Logo_Png.png">
    <link rel="stylesheet" href="/profile/profile.css">
</head>

<body>
    <?php
    include('../common/navbar-login.php');
    ?>
    <form action="/profile/action-save.php" enctype="multipart/form-data" method="post">
        <div class="container">
            <h2>PROFIL PENGGUNA</h2>

            <input type="file" name="image" id="fileInput" accept="image/*" style="display: none;">

            <div class="profile-section">
                <div class="fotoprofile" id="profileImageContainer" onclick="document.getElementById('fileInput').click();">
                    <img id="profileImage" alt="Profile Picture" height="154" src="/uploads/<?php echo $user['image'] ? $user['image'] : 'avatar.png' ?>" width="144" />
                    <p>Unggah Foto</p>
                </div>
                <input type="hidden" name="user_id" value="<?php echo $_SESSION['user']['id'] ?>">

                <div class="form-section">
                    <div class="form-group">
                        <label for="first-name">Nama Lengkap</label>
                        <input id="first-name" name="fullname" type="text" value="<?php echo $user['fullname'] ?>" />
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input id="email" name="email" type="email" value="<?php echo $user['email'] ?>" />
                    </div>
                    <div class="form-group">
                        <label for="phone">No. Telepon</label>
                        <input id="phone" name="phone" type="tel" value="<?php echo $user['phone'] ?>" />
                    </div>
                </div>
            </div>

            <button class="logout-button"><a href="../logout">Keluar</a></button>
            <button class="logout-button" type="submit">Simpan</button>
        </div>
    </form>

    <script>
        // Menampilkan gambar yang diupload sebagai preview
        const fileInput = document.getElementById('fileInput');
        const profileImage = document.getElementById('profileImage');

        fileInput.addEventListener('change', function() {
            const file = fileInput.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    profileImage.src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>


</html>