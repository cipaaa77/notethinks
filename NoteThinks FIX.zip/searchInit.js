document.getElementById('searchButton').addEventListener('click', function () {
    let searchTerm = document.getElementById('searchInput').value.toLowerCase();
    let filterTerm = document.getElementById('filterSelect').value;

    // Update query parameters
    updateQueryParams(searchTerm, filterTerm);

    // Filter cards
    filterKategori(searchTerm, filterTerm);
});

document.getElementById('filterSelect').addEventListener('change', function () {
    let searchTerm = document.getElementById('searchInput').value.toLowerCase();
    let filterTerm = document.getElementById('filterSelect').value;

    // Update query parameters
    updateQueryParams(searchTerm, filterTerm);

    // Filter cards
    filterKategori(searchTerm, filterTerm);
});

function filterKategori(searchTerm, filterTerm) {
    let cards = document.querySelectorAll('.card');

    cards.forEach(function (card) {
        let title = card.querySelector('.title').textContent.toLowerCase();
        let category = card.querySelector('.category').textContent.trim();

        if (title.includes(searchTerm) && (filterTerm === "" || category.includes(filterTerm))) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
}

function updateQueryParams(searchTerm, filterTerm) {
    let params = new URLSearchParams(window.location.search);

    if (searchTerm) {
        params.set('q', searchTerm);
    } else {
        params.delete('q');
    }

    if (filterTerm) {
        params.set('filter', filterTerm);
    } else {
        params.delete('filter');
    }

    window.history.replaceState({}, '', `${window.location.pathname}?${params.toString()}`);
}

window.addEventListener('DOMContentLoaded', function () {
    let params = new URLSearchParams(window.location.search);

    let initialSearchTerm = params.get('q') || "";
    let initialFilterTerm = params.get('filter') || "";

    document.getElementById('searchInput').value = initialSearchTerm;
    document.getElementById('filterSelect').value = initialFilterTerm;

    filterKategori(initialSearchTerm.toLowerCase(), initialFilterTerm);
});