<?php
include_once '../config/database.php'; // Tidak perlu parameter conn lagi karena sudah di-include di sini

function getUserRating($conn, $userId, $materiId)
{
    $query = "SELECT *
    FROM komentar_rating
    WHERE user_id = ? AND komentar_id = ?;";

    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("ii", $userId, $materiId);
    $stmt->execute();
    $result = $stmt->get_result();
    $ratedMateri = [];
    while ($row = $result->fetch_assoc()) {
        $ratedMateri[] = $row;
    }
    $stmt->close();
    return $ratedMateri;
}

function setRating($conn, $userId, $komentarId, $rating)
{
    $query = "INSERT INTO komentar_rating (user_id, komentar_id, rating)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE 
    rating = VALUES(rating),
    tanggal_disimpan = CURRENT_TIMESTAMP;
    ";
    $stmt = $conn->prepare($query);

    $stmt->bind_param("iii", $userId, $komentarId, $rating);

    // Execute statement
    if ($stmt->execute()) {
        echo "Upsert successful";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

function deleteRating($conn, $userId, $komentarId)
{
    $query = "DELETE FROM komentar_rating WHERE user_id = ? AND komentar_id = ?
    ";
    $stmt = $conn->prepare($query);

    $stmt->bind_param("ii", $userId, $komentarId);

    // Execute statement
    if ($stmt->execute()) {
        echo "Delete successful";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
