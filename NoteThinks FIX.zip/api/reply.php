<?php
include_once '../config/database.php'; // Tidak perlu parameter conn lagi karena sudah di-include di sini

// CREATE Reply
function tambahReply($conn, $komentar_id, $user_id, $reply)
{
    $query = "INSERT INTO reply (komentar_id, user_id, reply) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error); 
    }
    $stmt->bind_param("iis", $komentar_id, $user_id, $reply);
    $stmt->execute();
    $stmt->close();
}

// READ Reply
function getReplyByKomentarId($conn, $komentar_id)
{
    $query = "SELECT 
                r.id AS reply_id,
                r.reply,
                r.tanggal_reply,
                u.id AS user_id,
                u.fullname AS user_fullname,
                u.email AS user_email,
                u.image AS user_image
              FROM reply r
              JOIN users u ON r.user_id = u.id
              WHERE r.komentar_id = ?
              ORDER BY r.tanggal_reply ASC"; // Balasan diurutkan berdasarkan waktu

    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing query: ' . $conn->error);
    }

    $stmt->bind_param("i", $komentar_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $replies = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $replies;
}

// UPDATE Reply
function updateReply($conn, $id, $reply)
{
    $query = "UPDATE reply SET reply = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("si", $reply, $id);
    $stmt->execute();
    $stmt->close();
}

// DELETE Reply
function deleteReply($conn, $id)
{
    $query = "DELETE FROM reply WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
