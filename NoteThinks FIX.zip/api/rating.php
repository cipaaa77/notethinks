<?php
require_once('../config/database.php');

function getUserRating($conn, $userId, $materiId)
{
    $query = "SELECT *
    FROM materi_rating
    WHERE user_id = ? AND materi_id = ?;";

    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("ii", $userId, $materiId);
    $stmt->execute();
    $result = $stmt->get_result();
    $ratedMateri = [];
    while ($row = $result->fetch_assoc()) {
        $ratedMateri[] = $row;
    }
    $stmt->close();
    return $ratedMateri;
}

function setRating($conn, $userId, $materiId, $rating)
{
    $query = "INSERT INTO materi_rating (user_id, materi_id, rating)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE 
    rating = VALUES(rating),
    tanggal_disimpan = CURRENT_TIMESTAMP;
    ";
    $stmt = $conn->prepare($query);

    $stmt->bind_param("iii", $userId, $materiId, $rating);

    // Execute statement
    if ($stmt->execute()) {
        echo "Upsert successful";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
