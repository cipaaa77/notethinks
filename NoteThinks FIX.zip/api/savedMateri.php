<?php
include_once '../config/database.php'; // Tidak perlu parameter conn lagi karena sudah di-include di sini

// CREATE Saved Materi
function simpanMateri($conn, $user_id, $materi_id)
{
    $query = "INSERT INTO saved_materi (user_id, materi_id) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("ii", $user_id, $materi_id);
    $stmt->execute();
    $stmt->close();
}

// READ Saved Materi
function getSavedMateri($conn, $user_id)
{
    $query = "SELECT m.id, m.judul, m.image, m.deskripsi, m.tanggal_upload, m.kategori
FROM materi m
JOIN saved_materi sm ON m.id = sm.materi_id
WHERE sm.user_id = ?;
";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $savedMateri = [];
    while ($row = $result->fetch_assoc()) {
        $savedMateri[] = $row;
    }
    $stmt->close();
    return $savedMateri;
}

// DELETE Saved Materi
function hapusSavedMateri($conn, $user_id, $materi_id)
{
    $query = "DELETE FROM saved_materi WHERE user_id = ? AND materi_id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("ii", $user_id, $materi_id);
    $stmt->execute();
    $stmt->close();
}
