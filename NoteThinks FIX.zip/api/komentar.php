<?php
require_once '../config/database.php';

// CREATE Komentar
function tambahKomentar($conn, $materi_id, $user_id, $komentar)
{
    $query = "INSERT INTO komentar (materi_id, user_id, komentar) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("iis", $materi_id, $user_id, $komentar);
    $stmt->execute();
    $stmt->close();
}

function getKomentarByMateri($conn, $id, $user_id, $order = 'tanggal')
{
    if ($order == 'rating') {
        $orderByClause = "ORDER BY sum_rating DESC, c.tanggal_komentar DESC"; // Urutkan berdasarkan rating tertinggi, kemudian tanggal terbaru
    } else {
        $orderByClause = "ORDER BY c.tanggal_komentar DESC, sum_rating DESC"; // Default: urutkan berdasarkan tanggal terbaru, kemudian rating tertinggi
    }

    $query = "SELECT 
        c.id AS komentar_id,
        c.komentar,
        c.tanggal_komentar,
        u.id AS user_id,
        u.fullname AS user_fullname,
        u.image AS user_image,
        u.email AS user_email,
        COALESCE(sum_rating.sum_rating, 0) AS sum_rating, -- Menggunakan COALESCE untuk mengatasi NULL
        us.rating
    FROM komentar c
    JOIN users u ON c.user_id = u.id
    LEFT JOIN (
        SELECT 
            komentar_id, 
            SUM(rating) AS sum_rating -- Gunakan AVG untuk rata-rata
        FROM 
            komentar_rating
        GROUP BY 
            komentar_id
    ) sum_rating 
    ON c.id = sum_rating.komentar_id
    LEFT JOIN komentar_rating us ON c.id = us.komentar_id AND us.user_id = ?
    WHERE c.materi_id = ?
    $orderByClause";

    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("ii", $user_id, $id);
    $stmt->execute();
    $result = $stmt->get_result();

    $komentars = [];
    while ($komentar = $result->fetch_assoc()) {
        $komentars[] = $komentar;  // Tambahkan komentar ke array
    }
    $stmt->close();

    return $komentars;  // Kembalikan array yang berisi satu atau banyak komentar
}


// UPDATE Komentar
function updateKomentar($conn, $id, $komentar)
{
    $query = "UPDATE komentar SET komentar = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("si", $komentar, $id);
    $stmt->execute();
    $stmt->close();
}

// DELETE Komentar
function deleteKomentar($conn, $id)
{
    $query = "DELETE FROM komentar WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
