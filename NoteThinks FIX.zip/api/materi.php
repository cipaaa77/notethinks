<?php
require_once('../config/database.php');

// CREATE Materi
function tambahMateri($conn, $judul, $image, $deskripsi)
{
    $query = "INSERT INTO materi (judul, image, deskripsi) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("sss", $judul, $image, $deskripsi);
    $stmt->execute();
    $stmt->close();
}

function getAllMateri($conn)
{
    $sql = "SELECT * FROM materi";
    $result = $conn->query($sql);
    $materi = [];
    while ($row = $result->fetch_assoc()) {
        $materi[] = $row;
    }
    return $materi;
}

// READ Materi
function getMateri($conn, $id)
{
    $query = "SELECT 
        m.*,
        u.fullname as author_fullname,
        u.image as author_image 
    FROM materi m
    INNER JOIN users u
    ON m.author_id = u.id
    WHERE m.id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $materi = $result->fetch_assoc();
    $stmt->close();
    return $materi;
}

// UPDATE Materi
function updateMateri($conn, $id, $judul, $image, $deskripsi, $kategori)
{
    $query = "UPDATE materi SET judul = ?, image = ?, deskripsi = ?, kategori = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("ssssi", $judul, $image, $deskripsi, $kategori, $id);
    $stmt->execute();
    $stmt->close();
}

// DELETE Materi
function deleteMateri($conn, $id)
{
    $query = "DELETE FROM materi WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

function getMateriWithSaved($conn, $userId)
{
    $sql = "SELECT 
        m.id,
        m.judul,
        m.image,
        m.deskripsi,
        m.kategori,
        m.tanggal_upload,
    CASE 
        WHEN sm.id IS NOT NULL THEN TRUE 
        ELSE FALSE 
    END AS saved
    FROM 
        materi m
    LEFT JOIN 
        saved_materi sm 
    ON 
        m.id = sm.materi_id AND sm.user_id = $userId
    ORDER BY 
        m.tanggal_upload DESC;";

    $result = $conn->query($sql);
    $materi = [];
    while ($row = $result->fetch_assoc()) {
        $materi[] = $row;
    }
    return $materi;
}



function getMateriWithSavedAndRating($conn, $userId)
{
    $sql = "SELECT 
    m.id,
    m.judul,
    m.image,
    m.deskripsi,
    m.kategori,
    m.tanggal_upload,
    u.fullname AS author_fullname,
    u.image AS author_image,
    CASE 
        WHEN sm.id IS NOT NULL THEN TRUE 
        ELSE FALSE 
    END AS saved,
    mr.rating AS user_rating,
    avg_rating.average_rating AS rating_average
    FROM 
        materi m
    LEFT JOIN 
        saved_materi sm 
        ON m.id = sm.materi_id AND sm.user_id = $userId
    LEFT JOIN 
        materi_rating mr 
        ON m.id = mr.materi_id AND mr.user_id = $userId
    LEFT JOIN (
        SELECT 
            materi_id, 
            AVG(rating) AS average_rating
        FROM 
            materi_rating
        GROUP BY 
            materi_id
    ) avg_rating 
    ON m.id = avg_rating.materi_id
    LEFT JOIN
        users u
        ON m.author_id = u.id
    ORDER BY 
        m.tanggal_upload DESC;
    ";

    $result = $conn->query($sql);
    $materi = [];
    while ($row = $result->fetch_assoc()) {
        $materi[] = $row;
    }
    return $materi;
}
