<?php
include '../config/database.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM materi WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $materi = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $kategori = $_POST['kategori'];

    // Memeriksa apakah ada file gambar baru
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpName = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileType = $_FILES['image']['type'];
        $fileSize = $_FILES['image']['size'];

        $uploadDir = '../uploads/';
        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
        $newFileName = uniqid() . '.' . $fileExt;
        $fileDestination = $uploadDir . $newFileName;

        if (move_uploaded_file($fileTmpName, $fileDestination)) {
            $image = $newFileName;
        }
    } else {
        // Ambil nilai gambar lama dari database jika tidak ada input gambar baru
        $sql_get_image = "SELECT image FROM materi WHERE id = ?";
        $stmt_get_image = $conn->prepare($sql_get_image);
        $stmt_get_image->bind_param("i", $id);
        $stmt_get_image->execute();
        $result = $stmt_get_image->get_result();

        if ($row = $result->fetch_assoc()) {
            $image = $row['image'];  // Menetapkan gambar lama
        } else {
            // Tangani kasus jika tidak ada materi yang ditemukan
            echo "Materi tidak ditemukan.";
            exit();
        }
    }

    $sql = "UPDATE materi SET judul = ?, deskripsi = ?, kategori = ?, image = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $judul, $deskripsi, $kategori, $image, $id);

    if ($stmt->execute()) {
        header("Location: view_materi.php");
        exit();
    } else {
        echo "Gagal memperbarui materi.";
    }
}
$query2 = "SELECT * FROM kategori ORDER BY tanggal_upload DESC";
$query_run2 = mysqli_query($conn, $query2);
?>

<?php
include('includes/header.php');
include('includes/navbar.php');
?>

<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Edit Materi</h6>
        </div>
        <div class="card-body">
            <?php
            if (isset($_GET['id'])) {
                $id = $_GET['id'];

                // Fetch materi data from the database
                $query = "SELECT * FROM materi WHERE id = ?";
                if ($stmt = mysqli_prepare($conn, $query)) {
                    mysqli_stmt_bind_param($stmt, "i", $id);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);

                    // Check if a materi is found
                    if ($row = mysqli_fetch_assoc($result)) {
            ?>

                        <form action="edit_materi.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                            <div class="form-group">
                                <label for="judul">Judul</label>
                                <input type="text" name="judul" id="judul" value="<?php echo htmlspecialchars($row['judul']); ?>" class="form-control" placeholder="Enter Judul" required>
                            </div>

                            <div class="form-group">
                                <label for="deskripsi">Deskripsi</label>
                                <textarea name="deskripsi" id="deskripsi" class="form-control" placeholder="Enter Deskripsi" required><?php echo htmlspecialchars($row['deskripsi']); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label for="kategori">Kategori</label>
                                <select name="kategori" id="kategori" class="form-control" required>
                                    <?php
                                    if (mysqli_num_rows($query_run2) > 0) {
                                        $i = 1;
                                        while ($row2 = mysqli_fetch_assoc($query_run2)) {
                                    ?>
                                            <option value="<?php echo $row2['nama'] ?>" <?php echo $row['kategori'] == $row2['nama'] ? 'selected' : ''; ?>><?php echo $row2['nama'] ?></option>
                                    <?php }
                                    } ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="image">Gambar</label>
                                <input type="file" name="image" id="image" class="form-control-file">
                            </div>

                            <a href="view_materi.php" class="btn btn-danger">Cancel</a>
                            <button type="submit" name="updatebtn" class="btn btn-primary">Update</button>
                        </form>

            <?php
                    } else {
                        echo "Materi not found.";
                    }

                    mysqli_stmt_close($stmt);
                } else {
                    echo "Error preparing the query.";
                }
            } else {
                echo "No ID provided.";
            }
            ?>
        </div>
    </div>
</div>

<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>