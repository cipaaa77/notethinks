<?php
include '../../config/database.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM kategori WHERE nama = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $materi = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $nama = $_POST['nama'];

    // Memeriksa apakah ada file gambar baru
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpName = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileType = $_FILES['image']['type'];
        $fileSize = $_FILES['image']['size'];

        $uploadDir = '../../uploads/';
        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
        $newFileName = uniqid() . '.' . $fileExt;
        $fileDestination = $uploadDir . $newFileName;

        if (move_uploaded_file($fileTmpName, $fileDestination)) {
            $image = $newFileName;
        }
    } else {
        // Ambil nilai gambar lama dari database jika tidak ada input gambar baru
        $sql_get_image = "SELECT image FROM kategori WHERE nama = ?";
        $stmt_get_image = $conn->prepare($sql_get_image);
        $stmt_get_image->bind_param("i", $id);
        $stmt_get_image->execute();
        $result = $stmt_get_image->get_result();

        if ($row = $result->fetch_assoc()) {
            $image = $row['image'];  // Menetapkan gambar lama
        } else {
            // Tangani kasus jika tidak ada materi yang ditemukan
            echo "Materi tidak ditemukan.";
            exit();
        }
    }

    $sql = "UPDATE kategori SET nama = ?, image = ? WHERE nama = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nama, $image, $id);

    if ($stmt->execute()) {
        header("Location: /admin/kategori");
        exit();
    } else {
        echo "Gagal memperbarui materi.";
    }
}

?>

<?php
include('../includes/header.php');
include('../includes/navbar.php');
?>

<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Edit Materi</h6>
        </div>
        <div class="card-body">
            <?php
            if (isset($_GET['id'])) {
                $id = $_GET['id'];

                // Fetch materi data from the database
                $query = "SELECT * FROM kategori WHERE nama = ?";
                if ($stmt = mysqli_prepare($conn, $query)) {
                    mysqli_stmt_bind_param($stmt, "s", $id);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);

                    // Check if a materi is found
                    if ($row = mysqli_fetch_assoc($result)) {
            ?>

                        <form action="" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo $row['nama']; ?>">

                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" name="nama" id="nama" value="<?php echo htmlspecialchars($row['nama']); ?>" class="form-control" placeholder="Masukan nama" required>
                            </div>

                            <div class="form-group">
                                <label for="image">Gambar</label>
                                <input type="file" name="image" id="image" class="form-control-file">
                            </div>

                            <a href="./index.php" class="btn btn-danger">Cancel</a>
                            <button type="submit" name="updatebtn" class="btn btn-primary">Update</button>
                        </form>

            <?php
                    } else {
                        echo "Materi not found.";
                    }

                    mysqli_stmt_close($stmt);
                } else {
                    echo "Error preparing the query.";
                }
            } else {
                echo "No ID provided.";
            }
            ?>
        </div>
    </div>
</div>

<!-- /.container-fluid -->

<?php
include('../includes/scripts.php');
include('../includes/footer.php');
?>