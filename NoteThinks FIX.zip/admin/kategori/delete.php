
<?php
include '../../config/database.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM kategori WHERE nama = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);

    if ($stmt->execute()) {
        header("Location: /admin/kategori");
        exit();
    } else {
        echo "Gagal menghapus materi.";
    }
}
?>