<?php
include('../includes/header.php');
include('../includes/navbar.php');
require_once('../../config/database.php');

if (!isset($_GET['id'])) {
    header('Location: ' . $_SERVER['HTTP_REFERER']);
}

// Query to fetch single materi details
$id = $_GET['id'];
$query = "SELECT m.*, u.fullname AS author_fullname, u.image AS author_image FROM materi m JOIN users u ON m.author_id = u.id WHERE m.id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$materi = $result->fetch_assoc();
?>

<div class="container-fluid">

    <!-- Detail Materi -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-primary text-white">
            <h6 class="m-0 font-weight-bold">Detail Materi</h6>
        </div>

        <div class="card-body">
            <div class="d-flex justify-content-between mb-4">
                <a href="../kategori" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>

            <?php if ($materi): ?>
                <div class="text-center">
                    <!-- Judul Materi -->
                    <h1 class="h3 font-weight-bold mb-3 text-primary"><?php echo htmlspecialchars($materi['judul']); ?></h1>

                    <!-- Gambar Materi -->
                    <img src="/uploads/<?php echo htmlspecialchars($materi['image'] ?? 'default.png'); ?>"
                        alt="Materi Image"
                        class="img-fluid rounded mb-3 shadow-sm"
                        style="max-height: 300px; object-fit: cover;">

                    <!-- Deskripsi Materi -->
                    <p class="text-muted mb-4"><?php echo nl2br(htmlspecialchars($materi['deskripsi'] ?? 'Tidak ada deskripsi tersedia.')); ?></p>

                    <!-- Kategori -->
                    <button class="btn btn-outline-primary mb-4" disabled><?php echo htmlspecialchars($materi['kategori'] ?? 'Kategori tidak tersedia'); ?></button>
                </div>

                <!-- Author Section -->
                <div class="flex flex-row text-center mt-4">
                    <img src="/uploads/<?php echo htmlspecialchars($materi['author_image'] ?? 'default.png'); ?>"
                        alt="Author Image"
                        class="rounded-circle shadow-sm mb-2"
                        style="width: 70px; height: 70px; object-fit: cover;">
                    <div class="flex flex-col gap-2 justify-start">
                        <p class="font-weight-bold text-primary mb-1">@<?php echo htmlspecialchars($materi['author_fullname'] ?? 'Pengarang tidak diketahui'); ?></p>
                        <small class="text-muted">Author</small>
                    </div>
                </div>
            <?php else: ?>
                <!-- Ketika Data Tidak Ditemukan -->
                <div class="alert alert-warning text-center" role="alert">
                    Data materi tidak ditemukan.
                </div>
            <?php endif; ?>
        </div>
    </div>


    <!-- Komentar -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Komentar</h6>
        </div>

        <div class="card-body">
            <form action="./post_komentar.php" method="POST" class="mb-4">
                <div class="form-group">
                    <textarea name="comment" class="form-control" placeholder="Tulis Komentar Anda..." rows="4" required></textarea>
                </div>
                <input type="hidden" name="materi_id" value="<?php echo $id; ?>">
                <button type="submit" class="btn btn-success">Posting Komentar</button>
            </form>

            <div>
                <div class="d-flex justify-content-between mb-3">
                    <h6>Komentar</h6>
                    <div>
                        <a href="?id=<?php echo $id ?>&order=rating" class="btn btn-outline-primary btn-sm">Teratas</a>
                        <a href="?id=<?php echo $id ?>&order=tanggal" class="btn btn-outline-primary btn-sm">Terbaru</a>
                    </div>
                </div>

                <div id="commentsContainer">
                    <?php include('./materi_komentar.php'); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleReply(button) {
        const replyContainer = document.getElementById(button);
        if (replyContainer.style.display === "none") {
            replyContainer.style.display = "block";
        } else {
            replyContainer.style.display = "none";
        }
    }
</script>
<?php
include('../includes/scripts.php');
include('../includes/footer.php');
?>