<?php
require_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comment = trim($_POST['comment']);
    $materi_id = intval($_POST['materi_id']);

    // Validasi komentar
    if (empty($comment)) {
        die('Komentar tidak boleh kosong!');
    }

    session_start();
    if (!isset($_SESSION['user'])) {
        die('User belum login!');
    }
    $user_id = $_SESSION['user']['id'];

    $query = "INSERT INTO komentar (materi_id, user_id, komentar) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("iis", $materi_id, $user_id, $comment);
    $stmt->execute();
    $stmt->close();
    header('Location: ' . $_SERVER['HTTP_REFERER']);
}
