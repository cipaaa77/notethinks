<?php
require_once '../../config/database.php';

$query = "SELECT 
                r.id AS reply_id,
                r.reply,
                r.tanggal_reply,
                u.id AS user_id,
                u.fullname AS user_fullname,
                u.email AS user_email,
                u.image AS user_image
              FROM reply r
              JOIN users u ON r.user_id = u.id
              WHERE r.komentar_id = ?
              ORDER BY r.tanggal_reply ASC"; // Balasan diurutkan berdasarkan waktu

$stmt = $conn->prepare($query);
if ($stmt === false) {
    die('Error preparing query: ' . $conn->error);
}

$stmt->bind_param("i", $komentar_id);
$stmt->execute();
$result = $stmt->get_result();
$replies = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();


if (!empty($replies)) { ?>
    <div class="ml-8">
        <?php foreach ($replies as $reply) {
            $tanggalReply = !empty($reply['tanggal_reply']) ? date('d M Y H:i', strtotime($reply['tanggal_reply'])) : 'Tanggal tidak valid';
        ?>
            <div class="flex items-center mb-2">
                <div class="bg-gray-300 rounded-full w-8 h-8 flex items-center justify-center mr-2">
                    <img src="/uploads/<?php echo htmlspecialchars($reply['user_image'] ?? 'default.png'); ?>" alt="User Image">
                </div>
                <div>
                    <p class="font-bold"><?php echo htmlspecialchars($reply['user_fullname'] ?? 'Pengguna tidak diketahui'); ?> • <?php echo $tanggalReply; ?></p>
                    <p><?php echo nl2br(htmlspecialchars($reply['reply'] ?? 'Balasan tidak tersedia')); ?></p>
                </div>
            </div>
        <?php } ?>
    </div>
<?php } ?>