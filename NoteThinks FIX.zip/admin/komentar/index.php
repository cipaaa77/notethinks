<?php
include('../includes/header.php');
include('../includes/navbar.php');
require_once('../../config/database.php');

// Query to fetch materi from database
$query = "SELECT * FROM materi ORDER BY tanggal_upload DESC";
$query_run = mysqli_query($conn, $query);
?>

<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Materi
            </h6>
        </div>

        <div class="card-body">

            <?php
            if (isset($_SESSION['success']) && $_SESSION['success'] != '') {
                echo '<h2>' . $_SESSION['success'] . '</h2>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
                echo '<h2 class="bg-info">' . $_SESSION['status'] . '</h2>';
                unset($_SESSION['status']);
            }
            ?>

            <div class="table-responsive">

                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Gambar</th>
                            <th>Judul</th>
                            <th>Kategori</th>
                            <th>Tanggal Upload</th>
                            <th>EDIT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($query_run) > 0) {
                            $i = 1;
                            while ($row = mysqli_fetch_assoc($query_run)) {
                        ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><img width="96" src="/uploads/<?php echo $row['image'] ?>" alt=""></td>
                                    <td><?php echo $row['judul']; ?></td>
                                    <td><?php echo $row['kategori']; ?></td>
                                    <td><?php echo $row['tanggal_upload']; ?></td>
                                    <td>
                                        <a href="/admin/komentar/detail.php?id=<?php echo $row['id']; ?>" class="btn btn-success">Detail</a>
                                    </td>
                                </tr>
                        <?php
                            }
                        } else {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
include('../includes/scripts.php');
include('../includes/footer.php');
?>