<?php
require_once '../../config/database.php';
session_start();
if ($_POST['rating'] == 0) {
    $query = "DELETE FROM komentar_rating WHERE user_id = ? AND komentar_id = ?
    ";
    $stmt = $conn->prepare($query);

    $stmt->bind_param("ii", $_SESSION['user']['id'], $_POST['komentar_id']);

    // Execute statement
    if ($stmt->execute()) {
        echo "Delete successful";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    $query = "INSERT INTO komentar_rating (user_id, komentar_id, rating)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE 
    rating = VALUES(rating),
    tanggal_disimpan = CURRENT_TIMESTAMP;
    ";
    $stmt = $conn->prepare($query);

    $stmt->bind_param("iii", $_SESSION['user']['id'], $_POST['komentar_id'], $_POST['rating']);

    // Execute statement
    if ($stmt->execute()) {
        echo "Upsert successful";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

header('Location: ' . $_SERVER['HTTP_REFERER']);
