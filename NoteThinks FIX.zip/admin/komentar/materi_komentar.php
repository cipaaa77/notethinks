<?php
require_once '../../config/database.php';
function getKomentarByMateri($conn, $id, $user_id, $order = 'tanggal')
{
    if ($order == 'rating') {
        $orderByClause = "ORDER BY sum_rating DESC, c.tanggal_komentar DESC"; // Urutkan berdasarkan rating tertinggi, kemudian tanggal terbaru
    } else {
        $orderByClause = "ORDER BY c.tanggal_komentar DESC, sum_rating DESC"; // Default: urutkan berdasarkan tanggal terbaru, kemudian rating tertinggi
    }

    $query = "SELECT 
        c.id AS komentar_id,
        c.komentar,
        c.tanggal_komentar,
        u.id AS user_id,
        u.fullname AS user_fullname,
        u.image AS user_image,
        u.email AS user_email,
        COALESCE(sum_rating.sum_rating, 0) AS sum_rating, -- Menggunakan COALESCE untuk mengatasi NULL
        us.rating
    FROM komentar c
    JOIN users u ON c.user_id = u.id
    LEFT JOIN (
        SELECT 
            komentar_id, 
            SUM(rating) AS sum_rating -- Gunakan AVG untuk rata-rata
        FROM 
            komentar_rating
        GROUP BY 
            komentar_id
    ) sum_rating 
    ON c.id = sum_rating.komentar_id
    LEFT JOIN komentar_rating us ON c.id = us.komentar_id AND us.user_id = ?
    WHERE c.materi_id = ?
    $orderByClause";

    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("ii", $user_id, $id);
    $stmt->execute();
    $result = $stmt->get_result();

    $komentars = [];
    while ($komentar = $result->fetch_assoc()) {
        $komentars[] = $komentar;  // Tambahkan komentar ke array
    }
    $stmt->close();

    return $komentars;  // Kembalikan array yang berisi satu atau banyak komentar
}
$komentars = getKomentarByMateri($conn, $_GET['id'], $_SESSION['user']['id'], $_GET['order'] ?? 'tanggal');

if (empty($komentars)) {
    echo '<p>No comments found.</p>';
} else {
    foreach ($komentars as $komentar) {
        $komentar_id = $komentar['komentar_id'];
        $tanggalKomentar = !empty($komentar['tanggal_komentar']) ? date('d M Y H:i', strtotime($komentar['tanggal_komentar'])) : 'Tanggal tidak valid';
?>
        <div class="commentsContainer">
            <div class="bg-pink-100 p-4 rounded-lg mb-2 ml-8">
                <div class="flex flex-row items-center mb-2">
                    <div class="bg-gray-300 rounded-full w-8 h-8 flex items-center justify-center mr-2">
                        <img src="/uploads/<?php echo htmlspecialchars($komentar['user_image'] ?? 'default.png'); ?>" alt="User Image">
                    </div>
                    <div>
                        <p class="font-bold"><?php echo htmlspecialchars($komentar['user_fullname'] ?? 'Pengguna tidak diketahui'); ?> • <?php echo $tanggalKomentar; ?></p>
                        <p><?php echo nl2br(htmlspecialchars($komentar['komentar'] ?? 'Komentar tidak tersedia')); ?></p>
                    </div>
                </div>
                <div class="flex items-center mt-2"><button class="text-blue-500 mr-2" type="button" onclick="toggleReply('<?php echo 'komentar' . $komentar_id ?>')">Balas</button>
                    <form action="./score_komentar.php" method="post">
                        
                        <button type="submit" name="rating" value="<?php echo $komentar['rating'] == 1 ? 0 : 1 ?>" class="text-gray-500 mr-2">
                            <i class="<?php echo $komentar['rating'] == 1 ? 'fas' : 'far'; ?> fa-thumbs-up"></i>
                        </button>
                        <span><?php echo htmlspecialchars($komentar['sum_rating'] ?? '0'); ?></span>
                        <button type="submit" name="rating" value="<?php echo $komentar['rating'] == -1 ? 0 : -1 ?>" class="text-gray-500">
                            <i class="<?php echo $komentar['rating'] == -1 ? 'fas' : 'far'; ?> fa-thumbs-down"></i>
                        </button>
                        <input type="hidden" name="komentar_id" value="<?php echo $komentar_id; ?>" />
                    </form>
                </div>
                <?php include('./komentar_reply.php'); ?>
                <div id="<?php echo 'komentar' . $komentar_id ?>" class="reply-container" style="display: none;">
                    <form action="post_reply.php" method="POST">
                        <input type="hidden" name="materi_id" value="<?php echo htmlspecialchars($_GET['id']); ?>">
                        <input type="hidden" name="komentar_id" value="<?php echo $komentar_id; ?>">
                        <textarea class="w-full p-2 rounded mb-2" placeholder="Tulis Balasan Anda..." rows="2" name="reply"></textarea>
                        <button class="bg-pink-500 text-white px-4 py-2 rounded" type="submit">Kirim Balasan</button>
                    </form>
                </div>
            </div>
        </div>
<?php
    }
}
?>