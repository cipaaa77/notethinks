<?php
require_once '../../config/database.php'; // Pastikan file ini mengatur koneksi database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reply = trim($_POST['reply']);
    $komentar_id = intval($_POST['komentar_id']);
    $materi_id = intval($_POST['materi_id']);

    // Validasi komentar
    if (empty($reply)) {
        die('Komentar tidak boleh kosong!');
    }

    session_start();
    if (!isset($_SESSION['user'])) {
        die('User belum login!');
    }
    $user_id = $_SESSION['user']['id'];

    $query = "INSERT INTO reply (komentar_id, user_id, reply) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . $conn->error);
    }
    $stmt->bind_param("iis", $komentar_id, $user_id, $reply);
    $stmt->execute();
    $stmt->close();
    header('Location: ' . $_SERVER['HTTP_REFERER']);
}
