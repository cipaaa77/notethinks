<?php
include('includes/header.php'); 
include('includes/navbar.php'); 
require_once '../config/database.php';
?>

<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Edit Admin Profile</h6>
        </div>
        <div class="card-body">
        <?php
        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            // Fetch user data from the database
            $query = "SELECT * FROM users WHERE id = ?";
            if ($stmt = mysqli_prepare($conn, $query)) {
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);

                // Check if a user is found
                if ($row = mysqli_fetch_assoc($result)) {
                    ?>

                    <form action="./api/edit_admin.php" method="POST">
                        <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="edit_username" value="<?php echo htmlspecialchars($row['fullname']); ?>" class="form-control" placeholder="Enter Username" required>
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="edit_email" value="<?php echo htmlspecialchars($row['email']); ?>" class="form-control" placeholder="Enter Email" required>
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="edit_password" class="form-control" placeholder="Enter Password (leave empty to keep current)">
                        </div>

                        <div class="form-group">
                            <label>User Type</label>
                            <select name="user_type" class="form-control">
                                <option value="admin" <?php echo ($row['user_type'] === 'admin' ? 'selected' : ''); ?>>Admin</option>
                                <option value="user" <?php echo ($row['user_type'] === 'user' ? 'selected' : ''); ?>>User</option>
                            </select>
                        </div>

                        <a href="register.php" class="btn btn-danger">Cancel</a>
                        <button type="submit" name="updatebtn" class="btn btn-primary">Update</button>
                    </form>

                    <?php
                } else {
                    echo "User not found.";
                }

                mysqli_stmt_close($stmt);
            } else {
                echo "Error preparing the query.";
            }
        } else {
            echo "No ID provided.";
        }
        ?>
        </div>
    </div>
</div>

<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
