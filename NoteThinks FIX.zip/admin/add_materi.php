<?php
// include 'dbconfig.php';

// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     $judul = $_POST['judul'];
//     $deskripsi = $_POST['deskripsi'];

//     $sql = "INSERT INTO materi (judul, deskripsi) VALUES (?, ?)";
//     $stmt = $conn->prepare($sql);
//     $stmt->bind_param("ss", $judul, $deskripsi);

//     if ($stmt->execute()) {
//         header("Location: view_materi.php");
//         exit();
//     } else {
//         echo "Gagal menambahkan materi.";
//     }
// }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Materi</title>
</head>

<body>
    <h1>Tambah Materi</h1>
    <form action="./api/save_materi.php" method="POST" enctype="multipart/form-data">
        <label for="judul">Judul:</label>
        <input type="text" name="judul" id="judul" required><br>
        <label for="deskripsi">Deskripsi:</label>
        <textarea name="deskripsi" id="deskripsi" required></textarea><br>
        <label for="deskripsi">Kategori:</label>
        <select name="kategori">
            <option value="Matematika">Matematika</option>
            <option value="Ekonomi">Ekonomi</option>
            <option value="Kimia">Kimia</option>
            <option value="Pengetahuan%20Umum">Pengetahuan Umum</option>
            <option value="Biologi">Biologi</option>
            <option value="Bahasa%20Indonesia">Bahasa Indonesia</option>
            <option value="Sejarah">Sejarah</option>
            <option value="Bahasa%20Inggris">Bahasa Inggris</option>
        </select>
        <label for="deskripsi">Gambar:</label>
        <input type="file" name="image" id="">
        <button type="submit">Simpan</button>
    </form>
</body>

</html>