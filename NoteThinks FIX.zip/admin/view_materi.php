<?php
include('includes/header.php');
include('includes/navbar.php');
require_once('../config/database.php');

// Query to fetch materi from database
$query = "SELECT * FROM materi m ORDER BY tanggal_upload DESC";
$query_run = mysqli_query($conn, $query);
// Query to fetch materi from database
$query2 = "SELECT * FROM kategori ORDER BY tanggal_upload DESC";
$query_run2 = mysqli_query($conn, $query2);
?>

<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Materi
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addmateriModal">
                    Tambah Materi
                </button>
            </h6>
        </div>

        <div class="card-body">

            <?php
            if (isset($_SESSION['success']) && $_SESSION['success'] != '') {
                echo '<h2>' . $_SESSION['success'] . '</h2>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
                echo '<h2 class="bg-info">' . $_SESSION['status'] . '</h2>';
                unset($_SESSION['status']);
            }
            ?>

            <div class="table-responsive">

                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th></th>
                            <th>Judul</th>
                            <th>Kategori</th>
                            <th>Tanggal Upload</th>
                            <th>EDIT</th>
                            <th>DELETE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($query_run) > 0) {
                            $i = 1;
                            while ($row = mysqli_fetch_assoc($query_run)) {
                        ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><img width="96" src="/uploads/<?php echo $row['image'] ?>" alt=""></td>
                                    <td><?php echo $row['judul']; ?></td>
                                    <td><?php echo $row['kategori']; ?></td>
                                    <td><?php echo $row['tanggal_upload']; ?></td>
                                    <td>
                                        <a href="edit_materi.php?id=<?php echo $row['id']; ?>" class="btn btn-success">Edit</a>
                                    </td>
                                    <td>
                                        <a href="delete_materi.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Hapus</a>
                                    </td>
                                </tr>
                        <?php
                            }
                        } else {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal to Add Materi -->
<div class="modal fade" id="addmateriModal" tabindex="-1" role="dialog" aria-labelledby="addmateriModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addmateriModalLabel">Tambah Materi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="./api/save_materi.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="judul">Judul:</label>
                        <input type="text" name="judul" id="judul" class="form-control" required><br>
                    </div>

                    <div class="form-group">
                        <label for="deskripsi">Deskripsi:</label>
                        <textarea name="deskripsi" id="deskripsi" class="form-control" required></textarea><br>
                    </div>

                    <div class="form-group">
                        <label for="kategori">Kategori:</label>
                        <select name="kategori" id="kategori" class="form-control" required>
                            <?php
                            if (mysqli_num_rows($query_run2) > 0) {
                                $i = 1;
                                while ($row = mysqli_fetch_assoc($query_run2)) {
                            ?>
                                    <option value="<?php echo $row['nama'] ?>"><?php echo $row['nama'] ?></option>
                            <?php }
                            } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="image">Gambar:</label>
                        <input type="file" name="image" id="image" class="form-control" required><br>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="add_materi_btn" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>