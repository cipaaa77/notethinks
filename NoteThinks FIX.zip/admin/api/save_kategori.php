<?php
require_once '../../config/database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data
    $nama = htmlspecialchars(trim($_POST['nama']));

    // Validate that the file is an image and its size is within limits
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpName = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileType = $_FILES['image']['type'];
        $fileSize = $_FILES['image']['size'];

        // Define allowed file types and max file size (e.g., 5MB)
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 5 * 1024 * 1024; // 5MB in bytes

        // Check if the file type is allowed
        if (!in_array($fileType, $allowedTypes)) {
            echo "Only JPG, PNG, and GIF files are allowed.";
            exit;
        }

        // Check if the file size is within the limit
        if ($fileSize > $maxSize) {
            echo "File size should not exceed 5MB.";
            exit;
        }

        // Define upload directory
        $uploadDir = '../../uploads/';
        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
        $newFileName = uniqid() . '.' . $fileExt;
        $fileDestination = $uploadDir . $newFileName;

        // Move uploaded file to the desired directory
        if (move_uploaded_file($fileTmpName, $fileDestination)) {
            // Prepare and execute SQL query
            $query = "INSERT INTO kategori (nama, image) VALUES (?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $nama, $newFileName);

            if ($stmt->execute()) {
                // Redirect on success
                header('Location: /admin/kategori');
            } else {
                echo "Error: " . $stmt->error;
            }

            // Close statement
            $stmt->close();
        } else {
            echo "Gagal mengupload file.";
        }
    } else {
        echo "Error dalam upload file.";
    }
}
