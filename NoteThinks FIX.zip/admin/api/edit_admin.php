<?php
session_start();
require_once '../../config/database.php'; // Adjust the path as needed

if (isset($_POST['updatebtn'])) {
    // Get form data
    $edit_id = $_POST['edit_id'];
    $edit_username = $_POST['edit_username'];
    $edit_email = $_POST['edit_email'];
    $edit_password = $_POST['edit_password'];
    $user_type = $_POST['user_type'];

    // Initialize the query
    if (!empty($edit_password)) {
        // If password is provided, hash it
        $hashed_password = password_hash($edit_password, PASSWORD_BCRYPT);
        $query = "UPDATE users SET fullname = ?, email = ?, password = ?, user_type = ? WHERE id = ?";
        if ($stmt = mysqli_prepare($conn, $query)) {
            mysqli_stmt_bind_param($stmt, "ssssi", $edit_username, $edit_email, $hashed_password, $user_type, $edit_id);

            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['success'] = "Admin updated successfully";
                header('Location: /admin/register.php'); // Adjust to the correct redirect path
                exit();
            } else {
                $_SESSION['status'] = "Failed to update admin";
                header('Location: /admin/register.php'); // Adjust to the correct redirect path
                exit();
            }

            mysqli_stmt_close($stmt);
        } else {
            $_SESSION['status'] = "Error preparing the update query";
            header('Location: /admin/register.php'); // Adjust to the correct redirect path
            exit();
        }
    } else {
        // If password is not provided, update without changing the password
        $query = "UPDATE users SET fullname = ?, email = ?, user_type = ? WHERE id = ?";
        if ($stmt = mysqli_prepare($conn, $query)) {
            mysqli_stmt_bind_param($stmt, "sssi", $edit_username, $edit_email, $user_type, $edit_id);

            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['success'] = "Admin updated successfully";
                header('Location: /admin/register.php'); // Adjust to the correct redirect path
                exit();
            } else {
                $_SESSION['status'] = "Failed to update admin";
                header('Location: /admin/register.php'); // Adjust to the correct redirect path
                exit();
            }

            mysqli_stmt_close($stmt);
        } else {
            $_SESSION['status'] = "Error preparing the update query";
            header('Location: /admin/register.php'); // Adjust to the correct redirect path
            exit();
        }
    }
}
