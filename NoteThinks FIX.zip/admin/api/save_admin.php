<?php
session_start();  // Start the session if not already started
require_once '../../config/database.php';

if (isset($_POST['registerbtn'])) {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirmpassword'];

    if ($password === $confirm_password) {
        $hashed = password_hash($password, PASSWORD_BCRYPT);

        $query = "INSERT INTO users (fullname, email, password, user_type) VALUES (?, ?, ?, ?)";
        if ($stmt = mysqli_prepare($conn, $query)) {
            mysqli_stmt_bind_param($stmt, "ssss", $fullname, $email, $hashed, $user_type);

            $user_type = 'admin';

            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['success'] = "Admin is Added Successfully";
                header('Location: /admin/register.php');
                exit();
            } else {
                $_SESSION['status'] = "Admin is Not Added";
                header('Location: /admin/register.php');
                exit();
            }

            mysqli_stmt_close($stmt);
        } else {
            $_SESSION['status'] = "Error in preparing the query";
            header('Location: register.php');
            exit();
        }
    } else {
        $_SESSION['status'] = "Password and Confirm Password Does not Match";
        header('Location: /admin/register.php');
        exit();
    }
}
?>
