<?php
require '../../config/database.php';

session_start();
$email = $_POST['email'];
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();



    if (password_verify($password, $user['password']) && $user['user_type'] == 'admin') {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'name' => $user['fullname'],
            'email' => $user['email'],
            'image' => $user['image'],
            'user_type' => $user['user_type']
        ];
        header('Location: /admin');
    } else {
        $_SESSION['error'] = 'Kredensial tidak valid';
        header('Location: /admin/login.php');
    }
} else {
    $_SESSION['error'] = 'Kredensial tidak valid';
    header('Location: /admin/login.php');
}

$stmt->close();
$conn->close();
