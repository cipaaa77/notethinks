<?php
session_start(); // Start the session if not already started
require_once '../../config/database.php'; // Adjust the path as needed

if (isset($_POST['delete_id'])) {
    $id = $_POST['delete_id'];

    // Use a prepared statement to prevent SQL injection
    $query = "DELETE FROM users WHERE id = ?";
    if ($stmt = mysqli_prepare($conn, $query)) {
        // Bind the ID parameter
        mysqli_stmt_bind_param($stmt, "i", $id);

        // Execute the query
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success'] = "Your Data is DELETED";
            header('Location: /admin/register.php'); // Adjust to the correct redirect path
            exit();
        } else {
            $_SESSION['status'] = "Your Data is NOT DELETED";
            header('Location: /admin/register.php'); // Adjust to the correct redirect path
            exit();
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        $_SESSION['status'] = "Error preparing the delete query";
        header('Location: /admin/register.php'); // Adjust to the correct redirect path
        exit();
    }
} else {
    $_SESSION['status'] = "Invalid Request";
    header('Location: /admin/register.php'); // Adjust to the correct redirect path
    exit();
}
