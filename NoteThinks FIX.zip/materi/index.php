<?php
require_once('../api/materi.php');
session_start();
if (!isset($_GET['id']))
    header('Location: ' . $_SERVER['HTTP_REFERER']);

$materi = getMateri($conn, $_GET['id']);
?>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/Foto NoteThinks/Logo_Png.png">
    <title>NoteThinks</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap" rel="stylesheet" />
    <style>
        body {
            font-family: Arial, sans-serif;
        }
    </style>
</head>

<body class="bg-pink-100">
    <div class="max-w-2xl mx-auto p-4">
        <div class="flex justify-between items-center mb-4">
            <a href="../kategori" type="kembali">
                <i class="fas fa-arrow-left" style="font-size: 23px; margin-right: 5px;"></i>
            </a>
            <div>
                <h1 class="text-lg font-bold"><?php echo $materi['judul'] ?></h1>
            </div>
            <div>
                <button class="bg-white text-black px-4 py-2 rounded"><?php echo $materi['kategori'] ?></button>
            </div>
        </div>
        <div class="bg-pink-200 p-4 rounded-lg">
            <h2 class="text-center text-2xl font-bold mb-4"><?php echo $materi['judul'] ?></h2>
            <img alt="Diagram showing different types of fractions" class="mx-auto mb-4" height="300"
                src="/uploads/<?php echo $materi['image'] ?>"
                width="400" />
            <p class="mb-4">
                <?php echo $materi['deskripsi'] ?>
            </p>
        </div>
        <div class="flex items-center mt-4 mb-4">
            <img alt="User profile picture" class="rounded-full mr-2" height="50"
                src="/uploads/<?php echo $materi['author_image'] ?>"
                width="50" />
            <button class="bg-pink-500 text-white px-4 py-2 rounded">@<?php echo $materi['author_fullname'] ?></button>
        </div>
        <div class="bg-pink-200 p-4 rounded-lg mb-4">
            <h3 class="text-lg font-bold mb-2">Komentar &amp; Catatan</h3>
            <form action="/materi/post_komentar.php" method="POST">
                <textarea name="comment" class="w-full p-2 rounded mb-2" placeholder="Tulis Komentar Anda..." rows="4" required></textarea>
                <input type="hidden" name="materi_id" value="<?php echo $_GET['id']; ?>"> <!-- ID Materi -->
                <button type="submit" class="bg-pink-500 text-white px-4 py-2 rounded">Posting Komentar</button>
            </form>
        </div>
        <div class="bg-pink-200 p-4 rounded-lg">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-bold">Komentar</h3>
                <div>
                    <a href="./?id=<?php echo $_GET['id'] ?>&order=rating" class="bg-white text-black px-4 py-2 rounded mr-2 inline-block">Teratas</a>
                    <a href="./?id=<?php echo $_GET['id'] ?>&order=tanggal" class="bg-white text-black px-4 py-2 rounded inline-block">Terbaru</a>
                </div>
            </div>
            <div id="commentsContainer">
                <?php include('./materi_komentar.php') ?>
            </div>
        </div>
    </div>

    <script>
        function toggleReply(button) {
            const replyContainer = document.getElementById(button);
            if (replyContainer.style.display === "none") {
                replyContainer.style.display = "block";
            } else {
                replyContainer.style.display = "none";
            }
        }

        function postReply(button) {
            const replyText = button.previousElementSibling.value.trim();
            if (replyText) {
                const replyDiv = document.createElement('div');
                replyDiv.className = 'bg-pink-100 p-4 rounded-lg mb-2 ml-8'; // Memberikan indentasi pada balasan
                replyDiv.innerHTML = `
                    <div class="flex items-center mb-2">
                        <div class="bg-gray-300 rounded-full w-8 h-8 flex items-center justify-center mr-2">
                            <span class="text-lg font-bold">U</span>
                        </div>
                        <div>
                            <p class="font-bold">Anda • Sekarang</p>
                            <p>${replyText}</p>
                        </div>
                    </div>
                `;
                button.parentElement.parentElement.appendChild(replyDiv);
                button.previousElementSibling.value = ''; // Kosongkan input setelah posting
                button.parentElement.style.display = "none"; // Sembunyikan area balasan setelah mengirim
            }
        }
    </script>
</body>

</html>