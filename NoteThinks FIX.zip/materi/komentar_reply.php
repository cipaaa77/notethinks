<?php
require_once('../api/reply.php');
$replies = getReplyByKomentarId($conn, $komentar_id ?? '');
if (!empty($replies)) { ?>
    <div class="ml-8">
        <?php foreach ($replies as $reply) {
            $tanggalKomentar = !empty($reply['tanggal_reply']) ? date('d M Y H:i', strtotime($reply['tanggal_reply'])) : 'Tanggal tidak valid';

        ?>
            <div class="flex items-center mb-2">
                <div class="bg-gray-300 rounded-full w-8 h-8 flex items-center justify-center mr-2">
                    <img src="/uploads/<?php echo $reply['user_image'] ?>" alt="">
                </div>
                <div>
                    <p class="font-bold"><?php echo $reply['user_fullname'] ?> • <?php echo $tanggalKomentar ?></p>
                    <p><?php echo $reply['reply'] ?></p>
                </div>
            </div>
        <?php }; ?>
    </div>
<?php } ?>