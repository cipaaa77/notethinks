<?php
require_once '../api/komentarRating.php';
session_start();
if ($_POST['rating'] == 0)
    deleteRating($conn, $_SESSION['user']['id'], $_POST['komentar_id']);
else
    setRating($conn, $_SESSION['user']['id'], $_POST['komentar_id'], $_POST['rating']);

header('Location: ' . $_SERVER['HTTP_REFERER']);
