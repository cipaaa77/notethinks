<?php
require_once '../api/reply.php'; // Pastikan file ini mengatur koneksi database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reply = trim($_POST['reply']);
    $komentar_id = intval($_POST['komentar_id']);
    $materi_id = intval($_POST['materi_id']);

    var_dump($_POST);

    // Validasi komentar
    if (empty($reply)) {
        die('Komentar tidak boleh kosong!');
    }

    session_start();
    if (!isset($_SESSION['user'])) {
        die('User belum login!');
    }
    $user_id = $_SESSION['user']['id'];

    tambahReply($conn, $komentar_id, $user_id, $reply);
    header("Location: /materi?id=" . $materi_id);
}
