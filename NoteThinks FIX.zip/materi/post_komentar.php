<?php
require_once '../api/komentar.php'; // Pastikan file ini mengatur koneksi database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comment = trim($_POST['comment']);
    $materi_id = intval($_POST['materi_id']);

    // Validasi komentar
    if (empty($comment)) {
        die('Komentar tidak boleh kosong!');
    }

    session_start();
    if (!isset($_SESSION['user'])) {
        die('User belum login!');
    }
    $user_id = $_SESSION['user']['id'];

    tambahKomentar($conn, $materi_id, $user_id, $comment);
    header("Location: /materi?id=" . $materi_id);
}
