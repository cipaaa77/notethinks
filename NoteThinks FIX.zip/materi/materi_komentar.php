<?php
require_once '../api/komentar.php';
$komentars = getKomentarByMateri($conn, $_GET['id'], $_SESSION['user']['id'], $_GET['order'] ?? 'tanggal');

if (empty($komentars)) {
    echo '<p>No comments found.</p>';
} else {
    foreach ($komentars as $komentar) {
        $komentar_id = $komentar['komentar_id'];
        $tanggalKomentar = !empty($komentar['tanggal_komentar']) ? date('d M Y H:i', strtotime($komentar['tanggal_komentar'])) : 'Tanggal tidak valid';
?>
        <div class="commentsContainer">
            <div class="bg-pink-100 p-4 rounded-lg mb-2 ml-8">
                <div class="flex items-center mb-2">
                    <div class="bg-gray-300 rounded-full w-8 h-8 flex items-center justify-center mr-2">
                        <img src="/uploads/<?php echo $komentar['user_image'] ?>" alt="">
                    </div>
                    <div>
                        <p class="font-bold"><?php echo htmlspecialchars($komentar['user_fullname'] ?? 'Pengguna tidak diketahui'); ?> • <?php echo $tanggalKomentar; ?></p>
                        <p><?php echo nl2br(htmlspecialchars($komentar['komentar'] ?? 'Komentar tidak tersedia')); ?></p>
                    </div>
                </div>
                <div class="flex items-center mt-2">
                    <form action="/materi/score_komentar.php" method="post">
                        <button class="text-blue-500 mr-2" type="button" onclick="toggleReply('<?php echo 'komentar' . $komentar['komentar_id'] ?>')">Balas</button>

                        <button type="submit" name="rating" value="<?php echo $komentar['rating'] == 1 ? 0 : 1 ?>" class="text-gray-500 mr-2">
                            <i class="<?php echo $komentar['rating'] == 1 ? 'fas' : 'far' ?> fa-thumbs-up"></i>
                        </button>
                        <span><?php echo $komentar['sum_rating'] ?></span>
                        <button type="submit" name="rating" value="<?php echo $komentar['rating'] == -1 ? 0 : -1 ?>" class="text-gray-500">
                            <i class="<?php echo $komentar['rating'] == -1 ? 'fas' : 'far' ?> fa-thumbs-down"></i>
                        </button>
                        <input type="hidden" name="komentar_id" value="<?php echo $komentar['komentar_id'] ?>" />
                    </form>
                </div>
                <?php include('./komentar_reply.php') ?>
                <div id="<?php echo 'komentar' . $komentar['komentar_id'] ?>" class="reply-container" style="display: none;">
                    <form action="/materi/post_reply.php" method="POST">
                        <input type="hidden" name="materi_id" value="<?php echo $_GET['id'] ?>">
                        <input type="hidden" name="komentar_id" value="<?php echo $komentar['komentar_id'] ?>">
                        <textarea class="w-full p-2 rounded mb-2" placeholder="Tulis Balasan Anda..." rows="2" name="reply"></textarea>
                        <button class="bg-pink-500 text-white px-4 py-2 rounded" type="submit">Kirim Balasan</button>
                    </form>
                </div>
            </div>
        </div>
<?php
    }
}
?>