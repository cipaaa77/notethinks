<script>
    function showAlert() {
        alert("Anda Belum Masuk Kedalam Akun!");
    }
</script>
<header class="header">
    <img alt="NoteThinks Logo" src="/Foto NoteThinks/Logo_Png.png" />
    <nav>
        <button class="active" onclick="showAlert()">Beranda</button>
        <button onclick="showAlert()">Kategori</button>
        <button onclick="showAlert()">Favorit</button>
    </nav>
    <button class="login-btn"><a href="/login.php">Masuk</a></button>
</header>