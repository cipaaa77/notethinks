<div class="header">
    <img alt="Logo" height="40" src="/Foto NoteThinks/Logo_Png.png" width="40" />
    <nav>
        <a class="active" href="/">
            Beranda
        </a>
        <a href="../kategori">
            Kategori
        </a>
        <a href="../favorite">
            Favorit
        </a>
    </nav>
    <a href="/profile" class="fas fa-user-circle"
        style="font-size: 50px; color: black; text-decoration: none;"></a>
</div>