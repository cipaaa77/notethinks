<?php
require_once '../api/savedMateri.php';
session_start();
hapusSavedMateri($conn, $_SESSION['user']['id'], $_POST['materi_id']);
header('Location: ' . $_SERVER['HTTP_REFERER']);