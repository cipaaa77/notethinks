<?php
require_once "../api/materi.php";
session_start();
$materis = getMateriWithSavedAndRating($conn, $_SESSION['user']['id']);

$query2 = "SELECT nama FROM kategori ORDER BY tanggal_upload DESC";
$query_kategori = mysqli_query($conn, $query2);
?>
<html>

<head>
    <title>
        NoteThinks
    </title>
    <link rel="icon" href="/Foto NoteThinks/Logo_Png.png">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fce4ec;
            margin: 0;
            padding: 0;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f8bbd0;
            height: 50px;
            padding: 15px;
        }

        .header img {
            height: 7rem;
            width: auto;
            margin: 0px;
        }

        .header nav a {
            margin: 0 80px;
            text-decoration: none;
            color: black;
            font-weight: bold;
            font-size: 20px;
        }

        .header nav a.active {
            color: #d81b60;
        }

        .search-bar {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        .search-bar input {
            width: 75%;
            height: 50px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px 0 0 5px;
        }

        .search-bar button {
            padding: 10px;
            border: 1px solid #ccc;
            border-left: none;
            background-color: #f8bbd0;
            border-radius: 0 5px 5px 0;
            cursor: pointer;
        }

        .search-bar button i {
            color: #d81b60;
        }

        .filter-button {
            padding: 10px;
            border: 1px solid #ccc;
            background-color: #f8bbd0;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }

        .filter-button i {
            color: #d81b60;
        }

        .content {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin: 10px;
            width: 300px;
            overflow: hidden;
        }

        .card img {
            width: 300px;
            height: 200px;
        }

        .card-content {
            padding: 15px;
        }

        .card-content .category {
            color: #d81b60;
            font-weight: bold;
            justify-content: left;
        }

        .card-content .category .bookmark {
            float: right;
            margin-left: 10px;
        }

        .card-content .title {
            font-size: 18px;
            margin: 10px 0;
        }

        .card-content .title a {
            text-decoration: none;
            color: black;
        }


        .card-content .rating {
            color: #ff9800;
            margin-bottom: 10px;
        }

        .card-content .author {
            color: #757575;
        }

        .act-btn {
            background: #ff69b4;
            display: block;
            width: 50px;
            height: 50px;
            line-height: 50px;
            text-align: center;
            color: white;
            font-size: 40px;
            font-weight: bold;
            border-radius: 50%;
            -webkit-border-radius: 50%;
            text-decoration: none;
            transition: ease all 0.3s;
            position: fixed;
            right: 50px;
            bottom: 30px;
        }

        .act-btn:hover {
            background: #FFB7E2;
        }

        .popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }

        .popup-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            border-radius: 10px;
        }

        .popup-content button {
            padding: 10px 15px;
            background-color: #FFB7E2;
            /* Warna latar belakang tombol */
            color: white;
            /* Warna teks tombol */
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .popup-content button:hover {
            background-color: #d81b60;
            /* Warna latar belakang saat hover */
        }


        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .stars i {
            cursor: pointer;
            font-size: 24px;
            /* Ukuran bintang */
            color: #ccc;
            /* Warna default */
            transition: color 0.2s;
            /* Animasi transisi warna */
        }

        .stars i.active {
            color: gold;
            /* Warna bintang aktif (kuning) */
        }
    </style>
</head>

<body>
    <?php
    include('../common/navbar-login.php');
    ?>
    <div class="search-bar">
        <input id="searchInput" placeholder="Coba cari materi belajarmu disini" type="text" />
        <button id="searchButton">
            <i class="fas fa-search"></i>
        </button>
        <select id="filterSelect" class="filter-button">
            <option value="">Semua Kategori</option>
            <?php
            if (mysqli_num_rows($query_kategori) > 0) {
                $i = 1;
                while ($row = mysqli_fetch_assoc($query_kategori)) {
            ?>
                    <option value="<?php echo $row['nama'] ?>"><?php echo $row['nama'] ?></option>
            <?php }
            } ?>
        </select>
    </div>

    <div id="ratingPopup" class="popup" style="display:none;">
        <div class="popup-content">
            <form action="../rating/action.php" method="post">
                <input id="materiIdInput" type="hidden" name="materiId">
                <input id="ratingInput" type="hidden" name="rating">
                <span class="close" onclick="closeRatingPopup()">&times;</span>
                <h2>Nilai kepuasanmu terhadap materi ini</h2>
                <div class="stars">
                    <i class="far fa-star" onclick="setRating(1)"></i>
                    <i class="far fa-star" onclick="setRating(2)"></i>
                    <i class="far fa-star" onclick="setRating(3)"></i>
                    <i class="far fa-star" onclick="setRating(4)"></i>
                    <i class="far fa-star" onclick="setRating(5)"></i>
                </div>
                <p id="ratingValue">Kamu memberikan rating: </p>
                <button onclick="closeRatingPopup()" style="margin-top: 10px;">Oke</button>
            </form>
        </div>
    </div>
    <div class="content">
        <?php
        foreach ($materis as $materi) { ?>
            <div class="card">
                <img alt="Matematika - Trigonometri - Sin Cos Tan" height="200" src="/uploads/<?php echo $materi['image'] ?>"
                    width="300" />
                <div class="card-content">
                    <div class="category">
                        <?php echo $materi['kategori'] ?>
                        <form action="<?php echo $materi['saved'] ? '/kategori/remove_bookmark.php' : '/kategori/save_bookmark.php' ?>" method="post" id="bookmark-form-<?php echo $materi['id']; ?>">
                            <input type="hidden" name="materi_id" value="<?php echo $materi['id'] ?>">
                            <i class="<?php echo $materi['saved'] ? 'fas' : 'far' ?> fa-bookmark bookmark" onclick="submitBookmarkForm(<?php echo $materi['id']; ?>)"></i>
                        </form>
                    </div>
                    <div class="title">
                        <a href="/materi?id=<?php echo $materi['id'] ?>"><?php echo $materi['judul'] ?></a>
                    </div>
                    <div class="author">
                        @<?php echo $materi['author_fullname'] ?>
                    </div>
                </div>
            </div>
        <?php
        } ?>
    </div>
    <a href="/upload/upload.php" class="act-btn">+</a>
    <script src="/jsall.js"></script>
    <script src="../rating/rating.js"></script>
    <script src="../searchInit.js"></script>
    <script>
        function submitBookmarkForm(materiId) {
            const form = document.getElementById(`bookmark-form-${materiId}`);
            form.submit(); // Mengirimkan form
        }
    </script>

</body>

</html>