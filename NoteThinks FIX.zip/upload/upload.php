<?php
require_once('../config/database.php');
$query2 = "SELECT * FROM kategori ORDER BY tanggal_upload DESC";
$query_run2 = mysqli_query($conn, $query2);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notethinks</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <link rel="icon" href="/Foto NoteThinks/Logo_Png.png">
    <link rel="stylesheet" href="upload.css">
</head>

<body>
    <?php
    include('../common/navbar-login.php');
    ?>
    <h1>Tambah Materi</h1>
    <form action="/admin/api/save_materi.php" method="POST" enctype="multipart/form-data" style="max-width: 600px; margin: auto; padding: 1rem; border: 1px solid #ccc; border-radius: 8px;">
        <fieldset style="border: none; margin-bottom: 1rem;">
            <label for="judul" style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Judul:</label>
            <input type="text" name="judul" id="judul" required style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;">
        </fieldset>
        <fieldset style="border: none; margin-bottom: 1rem;">
            <label for="deskripsi" style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Deskripsi:</label>
            <textarea name="deskripsi" id="deskripsi" required style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;"></textarea>
        </fieldset>
        <fieldset style="border: none; margin-bottom: 1rem;">
            <label for="kategori" style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Kategori:</label>
            <select name="kategori" style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;">
                <?php
                if (mysqli_num_rows($query_run2) > 0) {
                    $i = 1;
                    while ($row = mysqli_fetch_assoc($query_run2)) {
                ?>
                        <option value="<?php echo $row['nama'] ?>"><?php echo $row['nama'] ?></option>
                <?php }
                } ?>
            </select>
        </fieldset>
        <fieldset style="border: none; margin-bottom: 1rem;">
            <label for="image" style="display: block; margin-bottom: 0.5rem; font-weight: bold;">Gambar:</label>
            <input type="file" name="image" id="image" style="width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px;">
        </fieldset>
        <button type="submit" style="display: block; width: 100%; padding: 0.7rem; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">Simpan</button>
    </form>


    <script src="/jsall.js"></script>
</body>

</html>