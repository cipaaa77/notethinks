function showRatingPopup(event, id, ratingBefore) {
    document.getElementById('materiIdInput').value = id
    event.stopPropagation();
    resetRating();
    document.getElementById('ratingPopup').style.display = 'block';

    setRating(ratingBefore ?? 0)
}

function closeRatingPopup() {
    document.getElementById('ratingPopup').style.display = 'none';
}

function setRating(rating) {
    // Ambil semua bintang dan reset warna
    document.getElementById('ratingInput').value = rating
    const stars = document.querySelectorAll('.stars i');
    stars.forEach((star, index) => {
        if (index < rating) {
            star.classList.add('active'); // Tambahkan kelas aktif untuk bintang yang diklik
        } else {
            star.classList.remove('active'); // Hapus kelas aktif untuk bintang yang tidak diklik
        }
    });

    document.getElementById('ratingValue').innerText = "Kamu memberikan rating: " + rating + " bintang";
}

function resetRating() {
    const stars = document.querySelectorAll('.stars i');
    stars.forEach(star => {
        star.classList.remove('active'); // Hapus kelas aktif dari semua bintang
    });
    document.getElementById('ratingValue').innerText = "Kamu memberikan rating: "; // Reset teks rating
}