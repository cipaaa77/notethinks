<?php
session_start();
require('../api/rating.php');

setRating($conn, $_SESSION['user']['id'], $_POST['materiId'], $_POST['rating']);
header('Location: ' . $_SERVER['HTTP_REFERER']);