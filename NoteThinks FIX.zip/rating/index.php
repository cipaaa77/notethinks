<html>

<head>
    <title>NoteThinks</title>
    <link rel="icon" href="/Foto NoteThinks/Logo_Png.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #ffeef2;
            width: 80%;
            max-width: 600px;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .header i {
            font-size: 24px;
            cursor: pointer;
        }

        .header h1 {
            font-size: 18px;
            margin: 0;
        }

        .header .send {
            font-size: 18px;
            color: #d81b60;
            cursor: pointer;
        }

        .file-box {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .file-box i {
            font-size: 24px;
            margin-right: 10px;
        }

        .file-box .file-info {
            display: flex;
            align-items: center;
        }

        .file-box .file-info span {
            font-size: 14px;
        }

        .file-box .file-info .file-name {
            font-weight: bold;
        }

        .file-box .file-info .file-size {
            color: #888;
        }

        .file-box .close {
            font-size: 18px;
            cursor: pointer;
        }

        .rating-section {
            text-align: center;
            margin-bottom: 20px;
        }

        .rating-section h2 {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .rating-section .stars {
            font-size: 24px;
            color: #000;
        }

        .preview {
            background-color: #fff;
            border-radius: 5px;
            padding: 15px;
            text-align: left;
        }

        .preview h3 {
            font-size: 14px;
            margin-bottom: 10px;
        }

        .preview p {
            font-size: 14px;
            margin: 0;
        }

        .preview .read-more {
            color: #d81b60;
            font-size: 14px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <i class="fas fa-arrow-left"></i>
            <h1>NILAI MATERI</h1>
            <span class="send">Kirim</span>
        </div>
        <div class="file-box">
            <div class="file-info">
                <i class="fas fa-file-alt"></i>
                <div>
                    <span class="file-name">Operasi Hitung Bilangan Pecahan.pdf</span><br>
                    <span class="file-size">5 MB</span>
                </div>
            </div>
            <i class="fas fa-times close"></i>
        </div>
        <div class="rating-section">
            <h2>Nilai kepuasanmu terhadap materi ini</h2>
            <div class="stars">
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>
            </div>
        </div>
        <div class="preview">
            <h3>Pratinjau</h3>
            <p>Pecahan adalah bagian dari suatu keseluruhan kuantitas tertentu. Dalam matematika, pecahan biasanya
                dituliskan dalam bentuk a/b, di mana a adalah pembilang (bilangan di atas garis pemisah) dan b adalah
                penyebut (bilangan di bawah garis pemisah). Contohnya, 1/2, 3/4, dan 5/7 adalah bentuk pecahan.</p>
            <span class="read-more">Baca selengkapnya<<<</span> </div> </div> </body> </html>