<?php
require_once './config/database.php';
session_start();
$query2 = "SELECT * FROM kategori ORDER BY tanggal_upload DESC";
$query_kategori = mysqli_query($conn, $query2);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NoteThinks</title>
    <link rel="icon" href="/Foto NoteThinks/Logo_Png.png">
    <?php
    if (isset($_SESSION['user']))
        echo '<link rel="stylesheet" href="./beranda-login.css">';
    else
        echo '<link rel="stylesheet" href="./beranda-guest.css">';
    ?>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
</head>

<body>
    <?php
    if (isset($_SESSION['user'])) {
        include('./common/navbar-login.php');
    ?>
        <main class="main-content">
            <h1>Selamat Datang di<br>NoteThinks!</h1>
            <p id="p1">Berbagi Pengetahuan Membangun Masa<br>Depan.</p>
            <div class="courses">
                <?php
                if (mysqli_num_rows($query_kategori) > 0) {
                    $i = 1;
                    while ($row = mysqli_fetch_assoc($query_kategori)) {
                ?>
                        <div class="course">
                            <img alt="Matematika" src="/uploads/<?php echo $row['image'] ?>" />
                            <div class="course-title"><?php echo $row['nama'] ?></div>
                            <button class="course-detail-btn">Lihat Detail</button>
                        </div>
                <?php }
                } ?>
            </div>
        </main>
        <a href="/upload/upload.php" class="act-btn">+</a>
    <?php
    } else {
        include('./common/navbar-guest.php');
    ?>
        <main class="main-content">
            <h1>Selamat Datang di<br>NoteThinks!</h1>
            <p id="p1">Berbagi Pengetahuan Membangun Masa<br>Depan.</p>
            <p id="p2">Untuk mendapatkan fitur yang lebih memuaskan</p>
            <button class="login-now-btn"><a href="./register">Daftar Sekarang!</a></button>
            <div class="courses">
                <?php
                if (mysqli_num_rows($query_kategori) > 0) {
                    $i = 1;
                    while ($row = mysqli_fetch_assoc($query_kategori)) {
                ?>
                        <div class="course">
                            <img alt="Matematika" src="/uploads/<?php echo $row['image'] ?>" />
                            <div class="course-title"><?php echo $row['nama'] ?></div>
                            <button class="course-detail-btn">Lihat Detail</button>
                        </div>
                <?php }
                } ?>
            </div>
        </main>';
    <?php
    }
    ?>

</body>

</html>