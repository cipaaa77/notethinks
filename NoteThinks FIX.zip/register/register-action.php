<?php
require '../config/database.php';

$hashedPassword = password_hash($_POST['password'], PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO users (email, fullname, password) VALUES (?, ?, ?)");

$stmt->bind_param("sss", $_POST['email'], $_POST['fullname'], $hashedPassword);

// Execute the statement
if ($stmt->execute()) {
    header("Location: /login");
} else {
    header("Location: /register");
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>