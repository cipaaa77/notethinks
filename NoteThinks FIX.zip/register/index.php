<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notethinks</title>
    <link rel="icon" href="/Foto NoteThinks/Logo_Png.png">
    <link rel="stylesheet" href="/register/buat.css">
</head>

<body>
    <script src="/register/jsall.js"></script>
    <div class="container">
        <div class="logo-form">
            <div class="logo">
                <img src="/Foto NoteThinks/Logo NoteThinks.jpg" alt="Notethinks Logo">
            </div>
            <div class="form-content">
                <h2>Buat akun Anda sekarang!</h2>
                <form action="/register/register-action.php" method="post">
                    <div class="form-group">
                        <label for="name">Nama Lengkap</label>
                        <input type="text" id="name" name="fullname" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Kata Sandi</label>
                        <input type="password" id="password" name="password" placeholder="Kata Sandi" required>
                    </div>
                    <button type="submit">Mendaftar</button>
                </form>
                <div class="login-link">
                    Punya akun? <a href="../login">Masuk</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>